<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/users/painelADM','UsersController@painelADM');
Route::get('/users/painelProf','UsersController@painelProf');
Route::get('/users/painelAluno','UsersController@painelAluno');
Route::get('/gerirUsuario', 'UsersController@gerir');
Route::get('/users', ['as'=>'users.index','uses'=>'UsersController@index']);
Route::get('/users/create','UsersController@create');
Route::post('users','UsersController@store');
Route::get('/users/{id}/edit','UsersController@edit');

Route::get('/users/{id}/confirmaVinculo','UsersController@CourseAluno');
Route::put('users/alunos/{id}','UsersController@updateAluno');

Route::get('/users/{id}','UsersController@show');
Route::put('users/{id}','UsersController@update');
Route::delete('users/{id}','UsersController@destroy');
Route::get('/trocaSenha','UsersController@trocarSenha');
Route::get('/vincularAl','UsersController@vincularAluno');

Route::get('/gerirCurso', 'CoursesController@gerir');
Route::resource('/courses','CoursesController',['parameters'=>['courses'=>'id']]);

Route::get('/gerirDisciplina', 'DisciplinesController@gerir');
Route::resource('/disciplines','DisciplinesController',['parameters'=>['courses'=>'id']]);

Route::get('/registerDisc', 'DisciplinesController@registerDisc');
Route::get('/get-disciplines/{course_id}', 'DisciplinesController@getDisciplines');

Route::get('viewAlldownloadfile', 'WorksController@downfunc');

//Route::get('/registerDisc', 'StaticPagesController@index');
//Route::get('/get-disciplines/{course_id}', 'StaticPagesController@getDisciplines');

Route::get('fileentry', 'WorksController@index');
Route::get('fileentry/get/{filename}', ['as' => 'getentry', 'uses' => 'WorksController@get']);
Route::post('fileentry/add',[ 'as' => 'addentry', 'uses' => 'WorksController@add']);
//Route::post('/upload','WorksController@store');