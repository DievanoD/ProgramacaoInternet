<?php

use Illuminate\Database\Seeder;

class WorksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Work::truncate();
        //factory(\App\Work::class, 5)->create();
        \App\Work::create(['title' => 'Comandos do Laravel', 'score' => '20 pontos', 'deadline' => 'indefinido', 'comment' => 'comandos', 'discipline_id' => 1, 'file_name' => 'Comandos Laravel.docx']);

        \App\Work::create(['title' => 'Cronograma monitoria 2017', 'score' => '25 pontos', 'deadline' => 'indefinido', 'comment' => 'Cronograma', 'discipline_id' => 2, 'file_name' => 'Cronograma monitoria (2017-1).pdf']);

        \App\Work::create(['title' => 'Edital Centro de idiomas 2017', 'score' => '25 pontos', 'deadline' => 'indefinido', 'comment' => 'Centro de Idiomas', 'discipline_id' => 3, 'file_name' => 'Edital Centro de idiomas 021- Basicos 2017 internos.pdf']);
    }
}
