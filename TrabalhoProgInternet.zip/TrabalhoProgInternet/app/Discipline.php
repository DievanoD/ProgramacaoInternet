<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Discipline extends Model
{
    protected $fillable=['course_id','name'];

    public function works()
    {
    	//Tradução: hasMany = 'tem muitos'
    	return $this->hasMany('App\Work');
    }

    public function courses()
    {
    	return $this->belongsToMany('App\Course','course__disciplines', 'course_id', 'discipline_id')->withPivot(['period']);
    }

    /*public function course(){
        return $this->belongsTo('\App\Course');
    }*/

}
