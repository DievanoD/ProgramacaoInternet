<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use \App\Discipline;
use \App\Course;
use \App\Course_Discipline;

class DisciplinesController extends Controller
{
    public function index()
    {
    	
    	$disciplines = Discipline::orderBy('id', 'desc')->paginate(5);

        $courses_discipline = [];

        foreach ($disciplines as $discipline) {
            $courses_discipline[] = Course_Discipline::where('discipline_id', $discipline->id)->get();
        }

    	return view('disciplines.index', compact('disciplines', 'courses_discipline'));
    }

    public function gerir()
    {
        return view('disciplines.gerenciarDisciplina');
    }

	public function create()
	{
        $courses = Course::all();
	    return view('disciplines.create', compact('courses'));
	}

	public function store(Request $request)
    {
        $discipline = Discipline::where('name',$request->name)->first();
        if(! $discipline) {

            $discipline = Discipline::create(['name' => $request->name]);

            foreach ($request->courses as $course) {
                Course_Discipline::create([
                    "course_id"=>$course,
                    "discipline_id"=>$discipline->id,
                    "period"=>" "
                    ]);
            }
        }
        return redirect('disciplines');
    }

    public function edit($id)
    {
        $discipline = Discipline::find($id);        

        $links = Course_Discipline::where('discipline_id', $discipline->id)->get();
        
        $coursesSelect = [];

        foreach ($links as $link) {
            $coursesSelect[] = $link->course->id;
        }

        $courses = Course::all();

        return view('disciplines.edit', compact('discipline', 'coursesSelect', 'courses'));
    }

	public function update(Request $request, $id)
    {
        $discipline = Discipline::where('id',$id)->first();
        if($discipline) {
            
            $discipline->fill(['name' => $request->name]);

            Course_Discipline::where("discipline_id", $discipline->id)->delete();

            foreach ($request->courses as $course) {
                Course_Discipline::create([
                    "course_id"=>$course,
                    "discipline_id"=>$discipline->id,
                    "period"=>" "
                    ]);
            }
        }
        return redirect('disciplines');
    }

	public function destroy($id){
        Discipline::find($id)->delete();
        return redirect('disciplines');
    }

    public function registerDisc(){

        $courses = Course::pluck('name', 'id');
        return view('disciplines.registrarDisciplina', compact('courses'));
    }

    public function getDisciplines($courseId)
    {
        $course = Course::find($courseId);
        $disciplines = $course->disciplines()->getQuery()->get(['id', 'name']);
        return Response::json($disciplines);
    }

}
