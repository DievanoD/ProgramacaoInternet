<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Http\Response;

use App\Http\Controllers\Controller;
use App\Work;

use DB;

class WorksController extends Controller
{
    public function downfunc(){
    	$downloads=DB::table('works')->get();
    	return view('downloads.viewfile', compact('downloads'));
    }

    public function index()
	{
		$entries = Work::all();
 
		return view('uploads.upload', compact('entries'));
	}

	public function get($filename){
	
		$entry = Work::where('file_name', '=', $filename)->firstOrFail();
		$file = Storage::disk('local')->get($entry->filename);
 
		return (new Response($file, 200))
              ->header('Content-Type', $entry->file_name);
	}
 
	public function add() {
 
		$file = Request::file('filefield');
		$extension = $file->getClientOriginalExtension();
		Storage::disk('local')->put($file->getFilename().'.'.$extension,  File::get($file));
		$entry = new Work();
		//$entry->title = $entry->get('title');
		//$entry->score = $entry->get('score');
		//$entry->deadline = $entry->get('deadline');
		//$entry->comment = $entry->get('comment');
		//$entry->mime = $file->getClientMimeType();
		//$entry->original_filename = $file->getClientOriginalName();
		$entry->file_name = $file->getFilename().'.'.$extension;
 
		$entry->save();
 
		return redirect('fileentry');	
	}

	public function store(Request $request)
    {
    	Work::create($request->all());
        if ($request->hasFile('filefield')) {
        	$request->file('filefield');

        	return $request->filefield->store('public');
        }else{
        	return 'Nem um arquivo selecionado';
        }
        
    }
}
