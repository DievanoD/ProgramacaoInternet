<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\{User, Course, Course_User};

class UsersController extends Controller
{
    public function index()
    {
    	//return \App\Post::all();
    	//$posts = post::all();
    	$users = User::paginate(5);
    	return view('users.index', compact('users'));
    }

    public function gerir()
    {
        return view('users.gerenciarUsuario');
    }

    public function create()
	{
	    return view('users.create');
	}

    public function painelADM()
    {
        return view('users.painelADM');
    }

    public function painelProf()
    {
        return view('users.painelProf');
    }

    public function painelAluno()
    {
        return view('users.painelAluno');
    }

    public function store(Request $request)
    {
        User::create($request->all());
        return redirect('users');
    }

    public function show ($id)
    {
        $user = User::find($id);
        return view('users.show', compact('user'));
    }

    public function edit($id)
    {
        $user = User::find($id);

        //$links = Course_User::where('course_id', $course->id)->get();

        return view('users.edit', compact('user'));
    }

    public function update(Request $request, $id)
    {
        User::find($id)->update($request->all());
        return redirect('users');
    }

    public function destroy($id)
    {
        User::find($id)->delete();
        return redirect('users');
    }

    public function trocarSenha()
    {
        return view('users.trocaSenha');
    }

    public function vincularAluno(){
        /*$users = User::paginate(5);

        $courses = Course::all();

        return view('users.vinculaAlunos', compact('users','courses'));*/
        $users = User::orderBy('id', 'desc')->paginate(5);

        $courses_user = [];

        foreach ($users as $user) {
            $courses_user[] = Course_User::where('user_id', $user->id)->get();
        }

        return view('users.vinculaAlunos', compact('users', 'courses_user'));
    }

    public function getUser($courseId)
    {
        $course = Course::find($courseId);
        $users = $course->users()->getQuery()->get(['id', 'name']);
        return Response::json($users);
    }

    public function CourseAluno($id){
        $user = User::find($id);        

        $links = Course_User::where('user_id', $user->id)->get();
        
        $coursesSelect = [];

        foreach ($links as $link) {
            $coursesSelect[] = $link->course->id;
        }

        $courses = Course::all();

        return view('users.confirmaVinculo', compact('user', 'coursesSelect', 'courses'));
    }

    public function updateAluno(Request $request, $id){
        $user = User::where('id',$id)->first();
        if($user) {
            
            $user->fill(['name' => $request->name]);

            Course_User::where("user_id", $user->id)->delete();

            foreach ($request->courses as $course) {
                Course_User::create([
                    "course_id"=>$course,
                    "user_id"=>$user->id,
                    ]);
            }
        }
        return redirect('vincularAl');
    }
}
