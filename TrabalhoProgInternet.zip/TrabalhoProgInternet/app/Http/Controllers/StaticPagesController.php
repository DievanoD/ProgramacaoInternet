<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use \App\Discipline;
use \App\Course;

class StaticPagesController extends Controller
{
    public function index(){
    	$courses = Course::pluck('name', 'id');
    	return view('disciplines.registrarDisciplina', compact('courses'));
    }

    public function  getDisciplines($courseId){
    	$course = Course::find($courseId);
    	$disciplines = $course->subjects()->getQuery()->get(['id', 'name']);
    	return Response::json($disciplines);
    }
}
