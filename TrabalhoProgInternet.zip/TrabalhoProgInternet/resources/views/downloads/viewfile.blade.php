@extends('layout')
@section('content')

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<style type="text/css">
		.wrapper{
			margin: 0 auto;
			width: 90%;
			margin-top: 40px;
		}
	</style>
</head>
<body>
	<div class="wrapper">
		<section class="panel panel-primary">
			<div class="panel-heading">
				Download de Trabalhos
			</div>

			<div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<th>Título</th>
						<th>Pontuação</th>
						<th>Data de Upload</th>
						<th>Prazo de entrega</th>
						<th>Comentário</th>
						<th>Ação</th>
					</thead>

					<tbody>
					@foreach($downloads as $down)
						<tr>
							<td>{{$down->title}}</td>
							<td>{{$down->score}}</td>
							<td>{{$down->created_at}}</td>
							<td>{{$down->deadline}}</td>
							<td>{{$down->comment}}</td>

							<td>
								<a href="download/{{$down->file_name}}" download="{{$down->file_name}}">
									<button type="button" class="btn btn-primary">
										<i class="glyphicon glyphicon-download-alt">
										Download
										</i>
									</button>
								</a>
							</td>
						</tr>
					@endforeach
					</tbody>
					
				</table>
			</div>
		</section>
	</div>

	<!-- Latest compiled and minified JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</body>
</html>
@endsection