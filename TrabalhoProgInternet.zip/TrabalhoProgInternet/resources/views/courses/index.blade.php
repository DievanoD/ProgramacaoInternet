@extends('layout')

@section('content')

	
	@foreach($courses as $course)

	
        <div class="panel-heading">
        	<span class="glyphicon glyphicon-list-alt"></span>

				<h1><a href="/courses/{{$course->id}}">{{$course->name}}</a></h1>
				<p>{{$course->abbreviation}}</p>

				{{Form::open(['url'=>'courses/'.$course->id,'method'=>'delete'])}}
					{{Form::hidden('course_id', $course->id)}}

					<div class="form-group">
							<a class="btn btn-info" href="/users/painelADM" role="button">Sair</a>

							<a class="btn btn-primary" href="/courses/{{$course->id}}/edit" role="button">Editar</a>

					        {{ Form::submit('Excluir Curso', array('class' => 'btn btn-danger')) }}

					        
					</div>
				{{Form::close()}}				
		</div>


	@endforeach

	{{ $courses->links() }}

@endsection