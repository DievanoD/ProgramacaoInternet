@extends('layout')

@section('content')

        <div class="panel-heading">
        	
        	{{Form::open(['url'=>'users/'.$user->id,'method'=>'put'])}}

        		<div class="form-group col-md-4">
					{{Form::label('name', 'Nome:')}}
					{{Form::text('name', $user->name, ['placeholder'=>'Insira um nome', 'class'=>'form-control'])}}
				</div>

				<div class="form-group col-md-4">
					{{Form::label('email', 'E-mail:')}}
					{{Form::text('email', $user->email, ['placeholder'=>'Insira um e-mail', 'class'=>'form-control'])}}
				</div>
				  
				<div class="form-group col-md-4">
					{{Form::label('login', 'Login:')}}
					{{Form::text('login', $user->login, ['placeholder'=>'Login', 'class'=>'form-control'])}}
				</div>
				
				<div class="form-group col-md-4">
					{{Form::label('password', 'Senha:')}}
					{{Form::text('password', $user->password, ['placeholder'=>'Senha', 'class'=>'form-control'])}}
				</div>

				<div class="form-group col-md-2">
					{{Form::label('year', 'Ano:')}}
					{{Form::text('year', $user->year, ['placeholder'=>'Ano','class'=>'date-own form-control'])}}

					<script type="text/javascript">
							$('.date-own').datepicker({
						minViewMode: 2,
						format: 'yyyy'
						});
					</script>
					
				</div>

				<div class="form-group col-md-6">					
					<center>
						<label for="campo3">Tipo</label><br>
	
						<div class="form-group col-md-12">
							
								<div class="form-group col-md-4">
									<label for="campo3">Administrador</label><br>
									@if($user->type === "Administrador")
										<label><input type="radio" name="type" value="Administrador" checked=""><img type="image" src="{{asset("img/admin.png")}}"  class="imgBtn5"/></label>
									@else
										<label><input type="radio" name="type" value="Administrador"><img type="image" src="{{asset("img/admin.png")}}"  class="imgBtn5"/></label>
									@endif
								</div>

								<div class="form-group col-md-4">
									<label for="campo3">Professor</label><br>
									@if($user->type === "Professor")
										<label><input type="radio" name="type" value="Professor" checked=""><img type="image" src="{{asset("img/professor.png")}}"  class="imgBtn5"/></label>
									@else
										<label><input type="radio" name="type" value="Professor"><img type="image" src="{{asset("img/professor.png")}}"  class="imgBtn5"/></label>
									@endif
								</div>

								<div class="form-group col-md-4">
									<label for="campo3">Aluno</label><br>
									@if($user->type === "Aluno")
										<label><input type="radio" name="type" value="Aluno" checked=""><img type="image" src="{{asset("img/aluno.png")}}"  class="imgBtn5"/></label>
									@else
										<label><input type="radio" name="type" value="Aluno"><img type="image" src="{{asset("img/aluno.png")}}"  class="imgBtn5"/></label>
									@endif							
								</div>							
						</div>
					</center>				
				</div>

				<div class="form-group col-md-12">
					<a class="btn btn-primary" href="/users" role="button">Voltar</a>
					{{Form::submit('Salvar', array('class' => 'btn btn-success')) }}
				</div>
		</div>
		
		

			
		{{Form::close()}}

@endsection