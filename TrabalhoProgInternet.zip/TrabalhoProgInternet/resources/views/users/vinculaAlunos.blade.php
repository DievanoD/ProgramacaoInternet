@extends('layout')

@section('content')

	@foreach($users as $key => $user)

        @if($user->type === "Aluno")
            <div class="form-group col-md-12">

                    <div class="form-group col-md-4">
                        <span class="glyphicon glyphicon-user"></span>

                            <h1><a href="/users/{{$user->id}}">{{$user->name}}</a></h1>
                            <p>{{$user->email}}</p>
                            <p>{{$user->password}}</p>
                            <p>{{$user->login}}</p>
                            <p>{{$user->type}}</p>
                            <p>{{$user->year}}</p>

                            {{Form::hidden('user_id', $user->id)}}

                            <div class="form-group">
                                <a class="btn btn-primary" href="/users/painelADM" role="button">Voltar</a>
                                <a class="btn btn-primary" href="/users/{{$user->id}}/confirmaVinculo" role="button">Editar</a>

                            </div>


                            {{Form::close()}}
                    </div>

                    <div class="form-group col-md-8">
						<h2>Curso Vinculado</h1>
                            <?php $n = 1; ?>
                            @foreach($courses_user[ $key ] as $link)
                                {{$n++ }} -
                                {{ $link->course['name'] }}
                                <br>
                            @endforeach

					</div>
    		</div>

        @endif
	@endforeach

	{{ $users->links() }}

@endsection
