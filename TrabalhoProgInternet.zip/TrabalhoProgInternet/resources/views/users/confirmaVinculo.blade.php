@extends('layout')

@section('content')

 <div class="panel-heading">
        	
        	{{Form::open(['url'=>'users/alunos/'.$user->id,'method'=>'put'])}}
        		 <div class="form-group col-md-12">

                    <div class="form-group col-md-4">
                        <span class="glyphicon glyphicon-user"></span>

                            <h1><a href="/users/{{$user->id}}">{{$user->name}}</a></h1>
                            <p>{{$user->email}}</p>
                            <p>{{$user->password}}</p>
                            <p>{{$user->login}}</p>
                            <p>{{$user->type}}</p>
                            <p>{{$user->year}}</p>

                            {{Form::hidden('user_id', $user->id)}}

                            <div class="form-group">                                
                                <div class="form-group col-md-12">
									<a class="btn btn-primary" href="/users" role="button">Voltar</a>
									{{Form::submit('Salvar', array('class' => 'btn btn-success')) }}
								</div>

                            </div>


                            {{Form::close()}}
                    </div>

                    <div class="form-group col-md-8">
						<h2>Vincular a Curso</h1>
                            <?php $n = 1; ?>
    						@foreach($courses as $course)
    							<input name='courses[]' type="radio" value="{{ $course->id }}">
    							{{Form::label('courses[]', $course->name)}}
    							<br>
    						@endforeach

					</div>
    		</div>

				

			{{Form::close()}}

</div>
		

@endsection