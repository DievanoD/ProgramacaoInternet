@extends('layout')

@section('content')

<!--scripts para o calendario de anos-->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>



	<div class="form-group col-md-12">
		
		<legend><strong>Painel de Controle Administrador</strong></legend><br>
		
			<div class="form-group col-md-2">
				<center><label>Gerenciar Usuário</label><br> 
					<a href="/gerirUsuario" class="hand"><img type="image" src="{{asset('img/usuario.png')}}" class="imgBtn5"></img></a>
				</center> 
			</div>

			<div class="form-group col-md-2">
				<center><label>Gerenciar Cursos</label><br> 
					<a href="/gerirCurso" class="hand"><img type="image" src="{{asset('img/ger-cursos.png')}}" class="imgBtn5"></img></a>
				</center> 
			</div>

			<div class="form-group col-md-2">
				<center><label>Gerenciar Disciplinas</label><br> 
					<a href="/gerirDisciplina" class="hand"><img type="image" src="{{asset('img/Disciplina.png')}}" class="imgBtn5"></img></a>
				</center> 
			</div>

			<div class="form-group col-md-2">
				<center><label>Gerenciar Alunos</label><br> 
					<a href="/vincularAl" class="hand"><img type="image" src="{{asset('img/aluno.png')}}" class="imgBtn5"></img></a>
				</center> 
			</div>

			<div class="form-group col-md-2">
				<center>
				<label for="campo2">Trocar senha</label><br> 
					<a href="/trocaSenha" class="hand"><img type="image" src="{{asset('img/trocaSenha.png')}}" class="imgBtn5"></img></a>
				</center>
			</div>			
		

		<br>		
	</div>

@endsection