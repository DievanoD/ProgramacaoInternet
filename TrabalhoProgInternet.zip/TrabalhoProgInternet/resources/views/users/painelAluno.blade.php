@extends('layout')

@section('content')

<!--scripts para o calendario de anos-->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>



	<div class="container">
		
			<legend>
				<strong>Painel de Controle Aluno</strong>
			</legend><br>
				<div class="row dadosLogin">
					<div class="form-group col-md-3">
						<center><label>Enviar Trabalho</label><br> 
							<a href="registerDisc" class="hand"><img type="image" src="{{asset('img/EnviarTrabalho.png')}}" class="imgBtn4"></img></a>
						</center> 
					</div>
					
					<div class="form-group col-md-3">
						<center><label>Download de Trabalhos</label><br> 
							<a href="/viewAlldownloadfile" class="hand"><img type="image" src="{{asset('img/DownloadTrabalho.png')}}" class="imgBtn4"></img></a>
						</center> 
					</div>

					<div class="form-group col-md-3">
						<center><label>Entrega de Trabalhos</label><br> 
							<a href="/gerir" class="hand"><img type="image" src="{{asset('img/entrTrab.png')}}" class="imgBtn4"></img></a>
						</center> 
					</div>

					<div class="form-group col-md-3">
						<center>
						<label for="campo2">Trocar senha</label><br> 
							<a href="/trocaSenha" class="hand"><img type="image" src="{{asset('img/trocaSenha.png')}}" alt="teste" class="imgBtn4"></img></a>
						</center>
					</div>
					
				</div>

				<br>
		
	</div>

@endsection
