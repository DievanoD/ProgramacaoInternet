@extends('layout')

@section('content')

 <div class="panel-heading">
        	
        	{{Form::open(['url'=>'disciplines/'.$discipline->id,'method'=>'put'])}}
        		<div class="form-group col-md-6">
					{{Form::label('name', 'Nome:')}}
					{{Form::text('name', $discipline->name, ['placeholder'=>'Insira um nome', 'class'=>'form-control'])}}
				</div>

				<div class="form-group col-md-6">
					{{Form::label('course', 'Vincule a um Curso:')}}<br>
						@foreach($courses as $course)
			                <input name='courses[]' {{ in_array($course->id, $coursesSelect) ? 'checked' : '' }} type="checkbox" value="{{ $course->id }}">
							{{Form::label('courses[]', $course->name)}}<br>
						@endforeach
				</div>


				<div class="form-group col-md-12">
					<a class="btn btn-primary" href="/disciplines" role="button">Voltar</a>
					{{Form::submit('Salvar', array('class' => 'btn btn-success')) }}
				</div>

			{{Form::close()}}

</div>
		

@endsection