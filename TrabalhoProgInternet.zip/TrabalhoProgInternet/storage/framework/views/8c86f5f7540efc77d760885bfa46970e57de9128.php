<style type="text/css">
	.link-show{
		color: #331189;
		cursor: pointer;
	}

</style>

<?php $__env->startSection('content'); ?>
	<div class="panel panel-default">
        <div class="panel-heading">
			<h1><?php echo e($course->name); ?></h1>

			<p><?php echo e($course->id); ?></p>
			<p><?php echo e($course->abbreviation); ?></p>

			<a class="btn btn-primary" href="/courses" role="button">Voltar</a>

		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>