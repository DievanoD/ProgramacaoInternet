<?php $__env->startSection('content'); ?>

        <div class="panel-heading">
        	
        	<?php echo e(Form::open(['url'=>'users/'.$user->id,'method'=>'put'])); ?>


        		<div class="form-group col-md-4">
					<?php echo e(Form::label('name', 'Nome:')); ?>

					<?php echo e(Form::text('name', $user->name, ['placeholder'=>'Insira um nome', 'class'=>'form-control'])); ?>

				</div>

				<div class="form-group col-md-4">
					<?php echo e(Form::label('email', 'E-mail:')); ?>

					<?php echo e(Form::text('email', $user->email, ['placeholder'=>'Insira um e-mail', 'class'=>'form-control'])); ?>

				</div>
				  
				<div class="form-group col-md-4">
					<?php echo e(Form::label('login', 'Login:')); ?>

					<?php echo e(Form::text('login', $user->login, ['placeholder'=>'Login', 'class'=>'form-control'])); ?>

				</div>
				
				<div class="form-group col-md-4">
					<?php echo e(Form::label('password', 'Senha:')); ?>

					<?php echo e(Form::text('password', $user->password, ['placeholder'=>'Senha', 'class'=>'form-control'])); ?>

				</div>

				<div class="form-group col-md-2">
					<?php echo e(Form::label('year', 'Ano:')); ?>

					<?php echo e(Form::text('year', $user->year, ['placeholder'=>'Ano','class'=>'date-own form-control'])); ?>


					<script type="text/javascript">
							$('.date-own').datepicker({
						minViewMode: 2,
						format: 'yyyy'
						});
					</script>
					
				</div>

				<div class="form-group col-md-6">					
					<center>
						<label for="campo3">Tipo</label><br>
	
						<div class="form-group col-md-12">
							
								<div class="form-group col-md-4">
									<label for="campo3">Administrador</label><br>
									<?php if($user->type === "Administrador"): ?>
										<label><input type="radio" name="type" value="Administrador" checked=""><img type="image" src="<?php echo e(asset("img/admin.png")); ?>"  class="imgBtn5"/></label>
									<?php else: ?>
										<label><input type="radio" name="type" value="Administrador"><img type="image" src="<?php echo e(asset("img/admin.png")); ?>"  class="imgBtn5"/></label>
									<?php endif; ?>
								</div>

								<div class="form-group col-md-4">
									<label for="campo3">Professor</label><br>
									<?php if($user->type === "Professor"): ?>
										<label><input type="radio" name="type" value="Professor" checked=""><img type="image" src="<?php echo e(asset("img/professor.png")); ?>"  class="imgBtn5"/></label>
									<?php else: ?>
										<label><input type="radio" name="type" value="Professor"><img type="image" src="<?php echo e(asset("img/professor.png")); ?>"  class="imgBtn5"/></label>
									<?php endif; ?>
								</div>

								<div class="form-group col-md-4">
									<label for="campo3">Aluno</label><br>
									<?php if($user->type === "Aluno"): ?>
										<label><input type="radio" name="type" value="Aluno" checked=""><img type="image" src="<?php echo e(asset("img/aluno.png")); ?>"  class="imgBtn5"/></label>
									<?php else: ?>
										<label><input type="radio" name="type" value="Aluno"><img type="image" src="<?php echo e(asset("img/aluno.png")); ?>"  class="imgBtn5"/></label>
									<?php endif; ?>							
								</div>							
						</div>
					</center>				
				</div>

				<div class="form-group col-md-12">
					<a class="btn btn-primary" href="/users" role="button">Voltar</a>
					<?php echo e(Form::submit('Salvar', array('class' => 'btn btn-success'))); ?>

				</div>
		</div>
		
		

			
		<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>