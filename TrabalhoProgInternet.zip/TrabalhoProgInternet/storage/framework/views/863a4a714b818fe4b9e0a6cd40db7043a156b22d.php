<?php $__env->startSection('content'); ?>

    
    <?php echo e(Form::open(['url'=>'users','method'=>'put'])); ?>


	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($user->type === "Aluno"): ?>
            <div class="form-group col-md-12">

                    <div class="form-group col-md-4">
                        <span class="glyphicon glyphicon-user"></span>

                            <h1><a href="/users/<?php echo e($user->id); ?>"><?php echo e($user->name); ?></a></h1>
                            <p><?php echo e($user->email); ?></p>
                            <p><?php echo e($user->password); ?></p>
                            <p><?php echo e($user->login); ?></p>
                            <p><?php echo e($user->type); ?></p>
                            <p><?php echo e($user->year); ?></p>

                            <?php echo e(Form::hidden('user_id', $user->id)); ?>


                            <div class="form-group">
                                <a class="btn btn-info" href="/users/gerenciaAl" role="button">Voltar</a>
                                <?php echo e(Form::submit('Salvar', array('class' => 'btn btn-success'))); ?>

                            </div>


                            <?php echo e(Form::close()); ?>

                    </div>

                    <div class="form-group col-md-8">
						<h2>Curso Vinculado</h1>
                            <?php $n = 1; ?>
    						<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    							<input name='courses[]' type="checkbox" value="<?php echo e($course->id); ?>">
    							<?php echo e(Form::label('courses[]', $course->name)); ?>

    							<br>
    						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>
    		</div>

        <?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php echo e($users->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>