<?php $__env->startSection('content'); ?>

	
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	
        <div class="panel-heading">
        	<span class="glyphicon glyphicon-user"></span>

				<h1><a href="/users/<?php echo e($user->id); ?>"><?php echo e($user->name); ?></a></h1>
				<p><?php echo e($user->email); ?></p>
				<p><?php echo e($user->password); ?></p>
				<p><?php echo e($user->login); ?></p>
				<p><?php echo e($user->type); ?></p>
				<p><?php echo e($user->year); ?></p>

				<!-- EXCLUIR USUÁRIOS -->
				<?php echo e(Form::open(['url'=>'users/'.$user->id,'method'=>'delete'])); ?>

					<?php echo e(Form::hidden('user_id', $user->id)); ?>


					<div class="form-group">
							<a class="btn btn-info" href="/users/painelADM" role="button">Voltar</a>

							<a class="btn btn-primary" href="/users/<?php echo e($user->id); ?>/edit" role="button">Editar</a>

					        <?php echo e(Form::submit('Excluir Usuário', array('class' => 'btn btn-danger'))); ?>


					        
					</div>
				<?php echo e(Form::close()); ?>				
		</div>


	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php echo e($users->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>