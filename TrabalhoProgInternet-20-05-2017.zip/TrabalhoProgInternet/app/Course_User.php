<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course_User extends Model
{
    //
}
