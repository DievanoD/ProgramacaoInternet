<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
    <div class="panel-heading">
	<?php echo e(Form::open(['url'=>'users','method'=>'POST'])); ?>

		<div class="row">
			<div class="col-md-4">
				<?php echo e(Form::label('name', 'Nome:')); ?>

				<?php echo e(Form::text('name', null, ['placeholder'=>'Insira um nome'])); ?>

			</div>
		
			<div class="col-md-4">
				<?php echo e(Form::label('email', 'E-mail:')); ?>

				<?php echo e(Form::text('email', null, ['placeholder'=>'Insira um e-mail'])); ?>

			</div>

			<div class="col-md-4">
				<?php echo e(Form::label('login', 'Login:')); ?>

				<?php echo e(Form::text('login', null, ['placeholder'=>'Login'])); ?>

			</div>
		</div>

		<div class="row">
			<div class="col-md-4">
				<?php echo e(Form::label('password', 'Senha:')); ?>

				<?php echo e(Form::text('password', null, ['placeholder'=>'Senha'])); ?>

			</div>

			<div class="col-md-4">
				<?php echo e(Form::label('type', 'Tipo:')); ?>

				<?php echo e(Form::text('type', null, ['placeholder'=>'Tipo do Usuário'])); ?>

			</div>

			<div class="col-md-4">
				<?php echo e(Form::label('year', 'Ano:')); ?>

				<?php echo e(Form::text('year', null, ['placeholder'=>'Ano'])); ?>

			</div>
		</div>
	</div>
</div>
		<a class="btn btn-primary" href="/users" role="button">Voltar</a>
		<?php echo e(Form::submit('Salvar', array('class' => 'btn btn-success'))); ?>


	<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>